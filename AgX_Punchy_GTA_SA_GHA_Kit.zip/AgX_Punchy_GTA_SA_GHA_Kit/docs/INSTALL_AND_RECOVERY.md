# Install / recovery

Expected data path:
`Android/data/com.rockstargames.gtasa/files/shaders/fragment/grading.glsl`

Expected native target:
`armeabi-v7a/libSAShaderL.so`

Install the native library through AML's mod-loading mechanism. Do not put the `.so` in the shader folder.

Recovery if graphics are broken:
1. Exit the game.
2. Rename `grading.glsl` to `grading.glsl.disabled` or move it out of `shaders/fragment/`.
3. Relaunch. SAShaderL should fall back to the game's built-in grading source when the override file cannot be opened.
4. If needed, disable/remove the SAShaderL mod using the normal AML mod management path.
