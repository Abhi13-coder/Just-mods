# Why the current shader cannot simply be loaded as a GTA material shader

The file declares `in vec2 vTexCoord`, `uniform sampler2D uColorTex`, and `out vec4 fragColor`. These are typical names for a custom screen-space pass, but GTA's generated material shaders use engine-specific varyings, samplers, and outputs. A loader that replaces a material shader does not automatically bind the final framebuffer to `uColorTex`.

A working implementation must do one of the following:

1. Add a real screen-space pass at a safe point after the game's scene has rendered, copy/bind the frame texture, set the uniforms, draw a fullscreen triangle/quad, and restore GL state; or
2. Rewrite the grading math into the actual compatible GTA material shaders, which changes individual materials rather than grading the whole frame.

This kit does not pretend either option has been implemented or tested. The build artifact is an upstream loader baseline only.
