#version 300 es
precision mediump float;

in vec2 vTexCoord;
uniform sampler2D uColorTex;

// Recommended starting values:
// uExposure   = 1.35
// uPunch      = 0.85
// uSaturation = 1.08
// uContrast   = 1.12

uniform float uExposure;
uniform float uPunch;
uniform float uSaturation;
uniform float uContrast;

out vec4 fragColor;

vec3 AgXDefault(vec3 x)
{
    x = max(x, 0.0);
    float a = 0.20;
    float b = 0.30;
    float c = 0.10;
    float d = 0.20;
    float e = 0.01;
    float f = 0.30;
    return clamp((x * (a * x + c * b) + d * e) / (x * (a * x + b) + d * f) - e / f, 0.0, 1.0);
}

vec3 ApplyPunchy(vec3 color, float punch)
{
    float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
    color = (color - 0.5) * mix(1.0, 1.25, punch) + 0.5;
    float sat = mix(1.0, 1.18, punch);
    color = mix(vec3(luma), color, sat);
    return color;
}

void main()
{
    vec3 color = texture(uColorTex, vTexCoord).rgb;

    // Exposure
    color *= uExposure;

    // AgX base tone mapping
    color = AgXDefault(color);

    // Punchy look
    color = ApplyPunchy(color, uPunch);

    // Extra controls
    float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
    color = mix(vec3(luma), color, uSaturation);
    color = (color - 0.5) * uContrast + 0.5;

    color = clamp(color, 0.0, 1.0);
    fragColor = vec4(color, 1.0);
}
