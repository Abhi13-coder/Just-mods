precision mediump float;

// GTA SA Android grading-pass interface from SAShaderL's bundled shader:
// sampler = Diffuse, texture coordinates = Out_Tex0.
uniform sampler2D Diffuse;
varying mediump vec2 Out_Tex0;
uniform mediump vec4 RedGrade;
uniform mediump vec4 GreenGrade;
uniform mediump vec4 BlueGrade;

// Conservative constants for GTA SA's SDR framebuffer.
const mediump float AGX_EXPOSURE = 1.04;
const mediump float AGX_PUNCH = 0.42;
const mediump float AGX_SATURATION = 1.04;
const mediump float AGX_CONTRAST = 1.035;

mediump vec3 AgXInspiredSDR(mediump vec3 x)
{
    x = max(x * AGX_EXPOSURE, vec3(0.0));

    // Soft highlight shoulder that mostly preserves normal SDR values.
    // Unlike the previous rational curve, this does not darken all midtones.
    mediump vec3 excess = max(x - vec3(0.78), vec3(0.0));
    x = x / (vec3(1.0) + excess * 0.30);

    // Gentle contrast around middle grey, with bounded punch.
    x = (x - vec3(0.18)) * (1.0 + 0.12 * AGX_PUNCH) + vec3(0.18);
    x = (x - vec3(0.5)) * AGX_CONTRAST + vec3(0.5);
    return clamp(x, 0.0, 1.0);
}

void main()
{
    mediump vec4 source = texture2D(Diffuse, Out_Tex0);

    // Preserve GTA's own time-cycle grading matrix before our look.
    mediump vec3 color;
    color.r = dot(source, RedGrade);
    color.g = dot(source, GreenGrade);
    color.b = dot(source, BlueGrade);

    color = AgXInspiredSDR(color);

    mediump float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
    color = mix(vec3(luma), color, AGX_SATURATION);

    gl_FragColor = vec4(clamp(color, 0.0, 1.0), source.a);
}
