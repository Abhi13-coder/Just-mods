# AgX Punchy for GTA SA Android (ARM32 / GitHub Actions)

This kit uses the actual grading shader override path exposed by AndroidModLoader/SAShaderL, rather than trying to replace an arbitrary material shader.

## Files

- `files/shaders/fragment/grading.glsl` is the **active GTA-compatible grading-pass shader**. It uses the interface from SAShaderL's bundled GTA grading shader: `Diffuse`, `Out_Tex0`, `RedGrade`, `GreenGrade`, and `BlueGrade`.
- `files/AgX_Punchy_Source_Original.shader` is your original standalone screen-space shader preserved for reference. Do not rename it directly to `grading.glsl`; its uniforms/varyings are not the GTA grading-pass interface.
- `.github/workflows/build.yml` builds upstream `libSAShaderL.so` for `armeabi-v7a` and packages the active shader at the matching `files/shaders/fragment/grading.glsl` location.

## Build from your phone

1. Create a GitHub repository and upload the contents of this kit, preserving the folders.
2. Open **Actions** and enable workflows if asked.
3. Run **Build AgX Punchy GTA SA ARM32**.
4. Open the successful run and download artifact `AgX-Punchy-GTA-SA-ARM32`.

The workflow is configured for 32-bit Android userspace (`armeabi-v7a`), matching the target device described for this project. GitHub Actions must finish successfully before an actual `.so` artifact exists.

## Install paths

1. Install `libSAShaderL.so` using the AML mod installation method for your GTA SA Android setup. The library belongs in the AML mods location, not the game's `files` folder.
2. Copy the packaged shader to:

   `/storage/emulated/0/Android/data/com.rockstargames.gtasa/files/shaders/fragment/grading.glsl`

   Create the `shaders/fragment` directories if missing. This is the path SAShaderL builds from `aml->GetAndroidDataPath()`.
3. Keep your original shader elsewhere for backup. The active `grading.glsl` must keep the GTA grading interface.

## Honest status

This is a real integration path in SAShaderL: its `OnModLoad()` checks `files/shaders/fragment/grading.glsl` and substitutes that source for the game's `gradingPShader`. The workflow builds the upstream loader and packages the adapted shader. I have not run this library in your installed GTA SA build, so game stability and visual appearance still need an in-game test. If the game crashes or grading disappears, remove/rename `grading.glsl` first to restore the built-in grading shader; keep the loader only if the rest of your mod setup requires it.

The look is **AgX-inspired SDR grading**, not the official full AgX transform. It preserves GTA's time-cycle grading matrix, adds restrained exposure/contrast/saturation, and uses a gentle highlight shoulder. No full-screen framebuffer capture hook is needed because SAShaderL already exposes the game's grading pass.
